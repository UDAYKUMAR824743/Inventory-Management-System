import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ItemProvider } from './context/ItemContext';
import Layout from './components/Layout';
import ViewItems from './pages/ViewItems';
import AddItem from './pages/AddItem';

function App() {
  return (
    <ItemProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Navigate to="/view-items" replace />} />
            <Route path="/view-items" element={<ViewItems />} />
            <Route path="/add-item" element={<AddItem />} />
          </Routes>
        </Layout>
      </Router>
    </ItemProvider>
  );
}

export default App;