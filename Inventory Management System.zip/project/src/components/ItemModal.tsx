import React from 'react';
import { X, Mail, Calendar, Tag } from 'lucide-react';
import { Item } from '../types/Item';
import ImageCarousel from './ImageCarousel';

interface ItemModalProps {
  item: Item;
  isOpen: boolean;
  onClose: () => void;
}

const ItemModal: React.FC<ItemModalProps> = ({ item, isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleEnquire = () => {
    // Simulate email sending
    const subject = `Enquiry for ${item.name}`;
    const body = `Hi,\n\nI am interested in the ${item.name} (${item.type}) and would like to know more details.\n\nThank you!`;
    
    // In a real application, this would make an API call to send email
    const mailtoLink = `mailto:info@inventory.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoLink);
    
    // Show success message
    alert(`Enquiry initiated for ${item.name}! Your default email client should open with a pre-filled message.`);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div 
          className="fixed inset-0 transition-opacity bg-black/60 backdrop-blur-sm" 
          onClick={onClose} 
        />
        
        <div className="inline-block w-full max-w-5xl my-8 overflow-hidden text-left align-middle transition-all transform bg-white/95 backdrop-blur-md shadow-2xl rounded-3xl border border-white/20">
          <div className="flex items-center justify-between p-6 border-b border-gray-200/50 bg-gradient-to-r from-blue-50 to-purple-50">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-1">{item.name}</h2>
              <p className="text-gray-600">Complete item details and specifications</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-white/60 rounded-full transition-all duration-200 hover:rotate-90"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          
          <div className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              <div>
                <ImageCarousel images={item.additionalImages} alt={item.name} />
              </div>
              
              <div className="space-y-8">
                <div className="flex items-center space-x-3">
                  <Tag className="h-5 w-5 text-blue-500" />
                  <span className="inline-block px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-blue-500 to-purple-500 rounded-full shadow-lg">
                    {item.type}
                  </span>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-gray-900 flex items-center">
                    <span className="w-1 h-6 bg-gradient-to-b from-blue-500 to-purple-500 rounded-full mr-3"></span>
                    Description
                  </h3>
                  <p className="text-gray-700 leading-relaxed text-lg bg-gray-50/50 p-4 rounded-xl">
                    {item.description}
                  </p>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-gray-900 flex items-center">
                    <span className="w-1 h-6 bg-gradient-to-b from-blue-500 to-purple-500 rounded-full mr-3"></span>
                    Details
                  </h3>
                  <div className="bg-gray-50/50 p-4 rounded-xl space-y-3">
                    <div className="flex items-center text-gray-600">
                      <Calendar className="h-5 w-5 mr-3 text-blue-500" />
                      <span className="font-medium">Added on:</span>
                      <span className="ml-2">{item.createdAt.toLocaleDateString('en-US', { 
                        weekday: 'long', 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Tag className="h-5 w-5 mr-3 text-blue-500" />
                      <span className="font-medium">Item ID:</span>
                      <span className="ml-2 font-mono text-sm bg-gray-200 px-2 py-1 rounded">#{item.id}</span>
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={handleEnquire}
                  className="w-full flex items-center justify-center space-x-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-4 px-8 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 transform"
                >
                  <Mail className="h-5 w-5" />
                  <span>Send Enquiry</span>
                </button>
                
                <p className="text-sm text-gray-500 text-center">
                  Click to send an enquiry email about this item
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ItemModal;