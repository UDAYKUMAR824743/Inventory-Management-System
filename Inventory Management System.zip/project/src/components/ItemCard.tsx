import React from 'react';
import { Item } from '../types/Item';
import { Calendar } from 'lucide-react';

interface ItemCardProps {
  item: Item;
  onClick: () => void;
}

const ItemCard: React.FC<ItemCardProps> = ({ item, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="bg-white/70 backdrop-blur-sm rounded-2xl shadow-sm hover:shadow-xl transition-all duration-500 cursor-pointer group overflow-hidden border border-white/20 hover:border-blue-200/50"
    >
      <div className="aspect-square bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden relative">
        <img
          src={item.coverImage}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
      
      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <h3 className="font-semibold text-gray-900 truncate text-lg group-hover:text-blue-600 transition-colors duration-300">
            {item.name}
          </h3>
          <span className="text-xs font-medium text-white bg-gradient-to-r from-blue-500 to-purple-500 px-3 py-1 rounded-full shadow-sm">
            {item.type}
          </span>
        </div>
        
        <p className="text-gray-600 text-sm line-clamp-2 mb-3 leading-relaxed">
          {item.description}
        </p>
        
        <div className="flex items-center text-xs text-gray-500">
          <Calendar className="h-3 w-3 mr-1" />
          <span>Added {item.createdAt.toLocaleDateString()}</span>
        </div>
      </div>
    </div>
  );
};

export default ItemCard;