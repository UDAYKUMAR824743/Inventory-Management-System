import React, { useEffect } from 'react';
import { CheckCircle, X } from 'lucide-react';

interface SuccessMessageProps {
  message: string;
  isVisible: boolean;
  onClose: () => void;
}

const SuccessMessage: React.FC<SuccessMessageProps> = ({ message, isVisible, onClose }) => {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onClose();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  if (!isVisible) return null;

  return (
    <div className="fixed top-6 right-6 z-50 max-w-sm animate-in slide-in-from-right duration-300">
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200/50 rounded-2xl p-5 shadow-2xl backdrop-blur-sm">
        <div className="flex items-start">
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-full p-1 mr-4 mt-0.5">
            <CheckCircle className="h-5 w-5 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="text-green-800 font-semibold mb-1">Success!</h4>
            <p className="text-green-700 text-sm">{message}</p>
          </div>
          <button
            onClick={onClose}
            className="ml-3 text-green-400 hover:text-green-600 transition-colors duration-200 hover:rotate-90"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default SuccessMessage;