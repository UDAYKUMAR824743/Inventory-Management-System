import React, { useState } from 'react';
import { useItems } from '../context/ItemContext';
import { ItemFormData } from '../types/Item';
import SuccessMessage from '../components/SuccessMessage';
import { Upload, X, Plus, Image as ImageIcon } from 'lucide-react';

const AddItem: React.FC = () => {
  const { addItem } = useItems();
  const [showSuccess, setShowSuccess] = useState(false);
  const [formData, setFormData] = useState<ItemFormData>({
    name: '',
    type: '',
    description: '',
    coverImage: null,
    additionalImages: []
  });

  const itemTypes = ['Shirt', 'Pant', 'Shoes', 'Sports Gear', 'Accessories', 'Electronics', 'Books', 'Other'];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCoverImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({ ...prev, coverImage: file }));
  };

  const handleAdditionalImagesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setFormData(prev => ({ ...prev, additionalImages: [...prev.additionalImages, ...files] }));
  };

  const removeAdditionalImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      additionalImages: prev.additionalImages.filter((_, i) => i !== index)
    }));
  };

  const createImageUrl = (file: File): string => {
    return URL.createObjectURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Convert files to URLs for demo purposes
    const coverImageUrl = formData.coverImage ? createImageUrl(formData.coverImage) : '';
    const additionalImageUrls = formData.additionalImages.map(file => createImageUrl(file));

    const newItem = {
      name: formData.name,
      type: formData.type,
      description: formData.description,
      coverImage: coverImageUrl,
      additionalImages: additionalImageUrls.length > 0 ? additionalImageUrls : [coverImageUrl]
    };

    addItem(newItem);
    setShowSuccess(true);
    
    // Reset form
    setFormData({
      name: '',
      type: '',
      description: '',
      coverImage: null,
      additionalImages: []
    });

    // Reset file inputs
    const coverInput = document.getElementById('coverImage') as HTMLInputElement;
    const additionalInput = document.getElementById('additionalImages') as HTMLInputElement;
    if (coverInput) coverInput.value = '';
    if (additionalInput) additionalInput.value = '';
  };

  return (
    <div>
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-3">
          Add New Item
        </h1>
        <p className="text-gray-600 text-lg max-w-2xl mx-auto">
          Fill in the details below to add a new item to your inventory with images and complete information
        </p>
      </div>

      <div className="max-w-3xl mx-auto">
        <form onSubmit={handleSubmit} className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-xl p-8 space-y-8 border border-white/20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-3">
                Item Name *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/80"
                placeholder="Enter item name"
              />
            </div>

            <div>
              <label htmlFor="type" className="block text-sm font-semibold text-gray-700 mb-3">
                Item Type *
              </label>
              <select
                id="type"
                name="type"
                value={formData.type}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/80 appearance-none cursor-pointer"
              >
                <option value="">Select item type</option>
                {itemTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-semibold text-gray-700 mb-3">
              Item Description *
            </label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              required
              rows={4}
              className="w-full px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none bg-white/80"
              placeholder="Describe the item in detail, including features, materials, and specifications"
            />
          </div>

          <div>
            <label htmlFor="coverImage" className="block text-sm font-semibold text-gray-700 mb-3">
              Cover Image *
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center hover:border-blue-400 transition-all duration-300 bg-gradient-to-br from-gray-50 to-blue-50/30">
              <input
                type="file"
                id="coverImage"
                accept="image/*"
                onChange={handleCoverImageChange}
                required
                className="hidden"
              />
              <label htmlFor="coverImage" className="cursor-pointer">
                {formData.coverImage ? (
                  <div className="space-y-4">
                    <img
                      src={createImageUrl(formData.coverImage)}
                      alt="Cover preview"
                      className="w-40 h-40 object-cover rounded-2xl mx-auto shadow-lg"
                    />
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-700">{formData.coverImage.name}</p>
                      <p className="text-xs text-gray-500">Click to change image</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                      <Upload className="h-8 w-8 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-gray-700 font-medium text-lg">Upload Cover Image</p>
                      <p className="text-sm text-gray-500 mt-1">PNG, JPG, GIF up to 10MB</p>
                    </div>
                  </div>
                )}
              </label>
            </div>
          </div>

          <div>
            <label htmlFor="additionalImages" className="block text-sm font-semibold text-gray-700 mb-3">
              Additional Images (Optional)
            </label>
            <div className="space-y-6">
              <div className="border-2 border-dashed border-gray-300 rounded-2xl p-6 text-center hover:border-blue-400 transition-all duration-300 bg-gradient-to-br from-gray-50 to-purple-50/30">
                <input
                  type="file"
                  id="additionalImages"
                  accept="image/*"
                  multiple
                  onChange={handleAdditionalImagesChange}
                  className="hidden"
                />
                <label htmlFor="additionalImages" className="cursor-pointer">
                  <div className="space-y-3">
                    <div className="bg-gradient-to-br from-purple-100 to-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto">
                      <Plus className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-gray-700 font-medium">Add More Images</p>
                      <p className="text-sm text-gray-500">Multiple images can be selected</p>
                    </div>
                  </div>
                </label>
              </div>

              {formData.additionalImages.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-gray-700 mb-4 flex items-center">
                    <ImageIcon className="h-4 w-4 mr-2" />
                    Additional Images ({formData.additionalImages.length})
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {formData.additionalImages.map((file, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={createImageUrl(file)}
                          alt={`Additional ${index + 1}`}
                          className="w-full h-24 object-cover rounded-xl shadow-md group-hover:shadow-lg transition-shadow duration-200"
                        />
                        <button
                          type="button"
                          onClick={() => removeAdditionalImage(index)}
                          className="absolute -top-2 -right-2 bg-red-500 hover:bg-red-600 text-white rounded-full p-1.5 shadow-lg transition-all duration-200 hover:scale-110"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-4 px-8 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 transform"
          >
            Add Item to Inventory
          </button>
        </form>
      </div>

      <SuccessMessage
        message="Item successfully added!"
        isVisible={showSuccess}
        onClose={() => setShowSuccess(false)}
      />
    </div>
  );
};

export default AddItem;